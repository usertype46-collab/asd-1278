# 粉體管理系統 — 雲端零環境自動編譯 APK 指南

1. 在 GitHub 建立一個新的 Repository。
2. 將此 ZIP 解壓縮後的所有檔案（包含隱藏資料夾 `.github`）上傳至該 Repository。
3. 點選上方 **Actions** 頁籤，等待約 2 分鐘編譯完成。
4. 點進編譯紀錄，在最下方 **Artifacts** 區塊即可直接下載安裝檔 `粉體管理系統-APK.zip`（內含 `app-debug.apk`）。